package t3a7;
import java.util.Scanner;
public class T3A7 {

    public static void main(String[] args) {
    ciclo();
    ejercicio2();
    ejercicio3();
    ejercicio4();
    }
    public static void ciclo(){
    Scanner obj = new Scanner (System.in);
    
    //Crear listra de numeros del 1 al 10 con el ciclo for
    for(int i=1; 1 <=10; i = i+1){
        System.out.println("Inicio: ");
        int inicio = obj.nextInt();
        
        System.out.println("Limite: ");
        int limite = obj.nextInt();
        
        System.out.println("Incremento: ");
        int Incremento = obj.nextInt();
        
        if (inicio < limite){
            for (int numero = inicio; numero <= limite; numero += Incremento){
                System.out.println("numero actual es " + numero);
            }
        }else if (limite < inicio){
            for (int numero = inicio; numero >= limite; numero -= Incremento){
                System.out.println("numero actual es " + numero);
            }
        }else{
            System.out.println("El inicio es identico al limite " + inicio + "-" + limite);
        }
    }
    }
    public static void ejercicio2 (){
        //Pedir los primero 10 números impares y calcular el producto.
        Scanner obj=new Scanner (System.in);
        
        System.out.println("bienvenido , por favor escriba los  primeros 10 numeros impares para realizar la suma");
        int num1=obj.nextInt();
        int num2=obj.nextInt();
        int num3=obj.nextInt();
        int num4=obj.nextInt();
        int num5=obj.nextInt();
        int num6=obj.nextInt();
        int num7=obj.nextInt();
        int num8=obj.nextInt();
        int num9=obj.nextInt();
        int num10=obj.nextInt();
        
        if ((num1%2)!=0 && (num2%2)!=0 && (num3%2)!=0 && (num4%2)!=0 && (num5%2)!=0 && (num6%2)!=0 && (num7%2)!=0 && (num8%2)!=0 && (num9%2)!=0 && (num10%2)!=0  ){
        
            int i;
            for (i=0;i==1;i=i+1){
            int resultado;
            resultado= num1 + num2 +num3 +num4 + num5 + num6 + num7 + num8 + num9 + num10;
                System.out.println("la suma de los numeros impares es " + resultado);
            }
            
        }
        else {
            System.out.println("ingrese bien los numeros impares");
        }
    }

        public static void ejercicio3 (){
        //Registrar una cantidad determinada de trabajadores: nombre y salario. Luego, calcular el promedio de los salarios.
        Scanner obj=new Scanner (System.in);
        int trabajador;
        int resultado=0;
        for (trabajador=0;trabajador<=4;trabajador=trabajador+1){
            System.out.println("bienvendio señor(a) por favor escribe su nombre");
            String nombre=obj.next();
            System.out.println("favor de ingresar su salario");
            int salario=obj.nextInt();
            resultado= resultado+salario;
            
        }
        int promedio ;
       promedio= resultado /5;
        System.out.println("el promedio del salario de los trabajadores es de " + promedio);
    }


   
        public static void ejercicio4 (){
        Scanner scanner = new Scanner(System.in);
        
        int edad;
        int mayorDe18 = 0;
        int mayorDe175 = 0;
        float estatura, sumaEstatura;
        double promedioEstatura;
        
        for(int i = 0; i <5; i++) {
            System.out.print("edad; ");
            edad = scanner.nextInt();
            
            if (edad < 18) {
                mayorDe18++;
            }
            System.out.println("Estatura: ");
            estatura = scanner.nextFloat();
            
            if(estatura > 1.75) {
                mayorDe175++;
            }
            estatura += estatura;
            //promedioEstatura = estatura/5;
            
            
        }
        System.out.print(" Mayor de 18 años: " + mayorDe18);
        System.out.print(" Mayor de 1.75 : " + mayorDe175);
    }
}


